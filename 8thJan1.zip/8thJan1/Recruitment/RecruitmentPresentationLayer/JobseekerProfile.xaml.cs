﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using RecruitmentEntities;
using Microsoft.Win32;
using System.IO;
using RecruitmentBusinessAccessLayer;
using RecruitmentExceptions;


namespace RecruitmentPresentationLayer
{
    /// <summary>
    /// Interaction logic for JobseekerProfile.xaml
    /// </summary>
    public partial class JobseekerProfile : Window
    {
        List<string> skillsFinance = new List<string> { "Interpersonal skills", "Ability to communicate", "Financial reporting" };
        List<string> skillsIT = new List<string> { "Problem Solving skills", "Web development", "Database designing", "Application Development" };
        List<string> skillsSales = new List<string> { "Communication", "Strategic Prospecting", "Time Management", "Buyer-Seller Agreement" };
        public JobseekerProfile()
        {
            InitializeComponent();
           // calDOB.Text = "01/08/2018";
            
        }

        private void button_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                OpenFileDialog openFile = new OpenFileDialog();

                if (openFile.ShowDialog().GetValueOrDefault())
                {
                    SaveFileDialog saveDialog = new SaveFileDialog();
                    string cpath = @"D://Images/";
                    saveDialog.FileName = cpath + Path.GetFileName(openFile.FileName);
                    File.Copy(openFile.FileName, saveDialog.FileName);
                    lblphoto.Content = saveDialog.FileName;
                    uploadstatus.Content = "Uploaded Successfully";
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            
        }

        private void btnSubmit_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                JobSeeker jsObj = new JobSeeker();
                MainWindow mainObj = new MainWindow();
                jsObj.JS_EMAILID = txtEmail.Text;
                jsObj.FIRSTNAME = txtfname.Text;
                jsObj.LASTNAME = txtlname.Text;
                jsObj.DOB = Convert.ToDateTime(calDOB.Text);
                jsObj.JS_CONTACT = Convert.ToInt64(txtMobile.Text);
                jsObj.PHOTO = lblphoto.Content.ToString();
                jsObj.HSC_BOARD = cbHSCBoard.Text;
                jsObj.HSC_PERCENTAGE = Convert.ToDecimal(txtHscPer.Text);
                jsObj.HSC_YOP = Convert.ToInt32(txtHscYear.Text);
                jsObj.SSC_BOARD = cbSscBoard.Text;
                jsObj.SSC_PERCENTAGE = Convert.ToDecimal(txtSscPer.Text);
                jsObj.SSC_YOP = Convert.ToInt32(txtSscYear.Text);
                jsObj.UG_UNIVERSITY = cbUGUniv.Text;
                jsObj.UG_PERCENTAGE = Convert.ToDecimal(txtUgPer.Text);
                jsObj.UG_YOP = Convert.ToInt32(txtUGYear.Text);
                jsObj.JS_EXPERIENCE = Convert.ToInt32( txtExp.Text);
                jsObj.JS_SKILLS = "";
                foreach (string item in skillsList.SelectedItems)
                {
                    jsObj.JS_SKILLS += item + ",";
                }
                jsObj.RESUME = lblresume.Content.ToString();

                BussinessRules balobj = new BussinessRules();
                bool jsadded = balobj.addJobSeeker(jsObj);

                if (jsadded)
                {
                    MessageBox.Show("Profile Saved");
                    //MainWindow obj = new MainWindow();
                    //obj.Show();
                    this.Close();   
                                   
                }
                    
                else
                    MessageBox.Show("Something went wrong");
            }
            catch(RecruitmentException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            

        }

        private void resumeUpload_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                OpenFileDialog openFile = new OpenFileDialog();

                if (openFile.ShowDialog().GetValueOrDefault())
                {
                    SaveFileDialog saveDialog = new SaveFileDialog();
                    string cpath = @"D://Resumes/";
                    saveDialog.FileName = cpath + Path.GetFileName(openFile.FileName);
                    File.Copy(openFile.FileName, saveDialog.FileName);
                    lblresume.Content = saveDialog.FileName;
                    resumeuploadstatus.Content = "Uploaded Successfully";
                }
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            
        }

        private void comboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            try
            {
                if (comboCategory.SelectedIndex == 1)
                {
                    skillsList.ItemsSource = skillsFinance;
                    
                }
                else if (comboCategory.SelectedIndex == 2)
                {
                    skillsList.ItemsSource = skillsIT;
                    
                }
                else if (comboCategory.SelectedIndex == 3)
                {
                    skillsList.ItemsSource = skillsSales;
                    
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
