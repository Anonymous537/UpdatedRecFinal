﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using RecruitmentBusinessAccessLayer;
using RecruitmentEntities;
using RecruitmentExceptions;

namespace RecruitmentPresentationLayer
{
    /// <summary>
    /// Interaction logic for EmployerProfile.xaml
    /// </summary>
    public partial class EmployerProfile : Window
    {
        public EmployerProfile()
        {
            InitializeComponent();
            try
            {
                BussinessRules balobj = new BussinessRules();
                //string cname = balobj.getCompanyName("career@infosys.com");
                //if(cname.Equals(""))
                //{
                //    txtCName.Text = "";
                //    txtCInfo.Text = "";
                //    txtClient.Text = "";
                //    txtContact.Text = "";
                //    txtWebsite.Text = "";
                //}
                //else
                //{
                //    Employer empobj = balobj.GetCompanyDetails(cname);
                //    //txtEmailId.Text = empobj.EMP_EMAILID;
                //    txtCName.Text = empobj.EMP_COMPANYNAME;
                //    txtCInfo.Text = empobj.COMPANYINFO;
                //    txtClient.Text = empobj.CLIENT;
                //    txtContact.Text = empobj.EMP_CONTACT.ToString();
                //    txtWebsite.Text = empobj.WEBSITE;
                //}
                
            }
            catch(Exception ex)
            {
                //MessageBox.Show(ex.Message);
            }
        }

        private void btnSubmit_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                string email = txtEmailId.Text;
                string cmpname = txtCName.Text;
                string cmpinfo = txtCInfo.Text;
                string client = txtClient.Text;
                decimal contactinfo = Convert.ToDecimal(txtContact.Text);
                string website = txtWebsite.Text;
                Employer employer = new Employer();
                employer.EMP_EMAILID = email;
                employer.EMP_COMPANYNAME = cmpname;
                employer.COMPANYINFO = cmpinfo;
                employer.CLIENT = client;
                employer.EMP_CONTACT = Convert.ToInt64(contactinfo);
                employer.WEBSITE = website;
                try
                {
                    bool added = BussinessRules.AddEmployerBL(employer);
                    if (added)
                    {
                        MessageBox.Show("Profile created sucessfully");
                        //EmployerHomePage obj = new EmployerHomePage();
                        //obj.lblcompany.Content = email;
                        //obj.Show();
                        //MainWindow obj = new MainWindow();
                        //obj.Show();
                        this.Close();
                    }
                        
                }
                catch (RecruitmentException ex)
                {
                    MessageBox.Show(ex.Message);
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            
        }

        //public static implicit operator EmployerProfile(JobseekerProfile v)
        //{
        //    throw new NotImplementedException();
        //}
    }
}
