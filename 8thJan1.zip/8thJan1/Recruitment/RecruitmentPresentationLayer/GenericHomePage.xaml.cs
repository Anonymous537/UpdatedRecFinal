﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using RecruitmentBusinessAccessLayer;
using RecruitmentEntities;
using RecruitmentExceptions;

namespace RecruitmentPresentationLayer
{
    /// <summary>
    /// Interaction logic for GenericHomePage.xaml
    /// </summary>
    public partial class GenericHomePage : Window
    {
        public GenericHomePage()
        {
            InitializeComponent();
        }

        private void logoutButton_Click(object sender, RoutedEventArgs e)
        {
            
        }

        private void loginButton_Click(object sender, RoutedEventArgs e)
        {
            MainWindow obj = new MainWindow();
            obj.Show();
            this.Close();
        }

        private void button_Click(object sender, RoutedEventArgs e)
        {
            SignUp obj = new SignUp();
            obj.Show();
            //this.Close();
        }

        private void lbIT_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            try
            {
                string company = (lbIT.SelectedItem as ListBoxItem).Content.ToString();
                ViewCompanyProfile Companyobj = new ViewCompanyProfile();
                BussinessRules balobj = new BussinessRules();
                Employer emp = balobj.GetCompanyDetails(company);
                //Companyobj.labelcompanyname.Content = emp.EMP_EMAILID;
                Companyobj.labelcompanyname.Content = emp.EMP_COMPANYNAME;
                Companyobj.txtabout.Text = emp.COMPANYINFO;
                //Companyobj.labelabout.Content = emp.COMPANYINFO;
                Companyobj.labelclient.Content = emp.CLIENT;
                Companyobj.labelcontact.Content = emp.EMP_CONTACT;
                Companyobj.labelwebsite.Content = emp.WEBSITE;

                Companyobj.Show();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void lbSales_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            try
            {
                string company = (lbSales.SelectedItem as ListBoxItem).Content.ToString();
                ViewCompanyProfile Companyobj = new ViewCompanyProfile();
                BussinessRules balobj = new BussinessRules();
                Employer emp = balobj.GetCompanyDetails(company);
                //Companyobj.labelcompanyname.Content = emp.EMP_EMAILID;
                Companyobj.labelcompanyname.Content = emp.EMP_COMPANYNAME;
                Companyobj.txtabout.Text = emp.COMPANYINFO;
                //Companyobj.labelabout.Content = emp.COMPANYINFO;
                Companyobj.labelclient.Content = emp.CLIENT;
                Companyobj.labelcontact.Content = emp.EMP_CONTACT;
                Companyobj.labelwebsite.Content = emp.WEBSITE;

                Companyobj.Show();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void lbMedical_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            try
            {
                string company = (lbMedical.SelectedItem as ListBoxItem).Content.ToString();
                ViewCompanyProfile Companyobj = new ViewCompanyProfile();
                BussinessRules balobj = new BussinessRules();
                Employer emp = balobj.GetCompanyDetails(company);
                //Companyobj.labelcompanyname.Content = emp.EMP_EMAILID;
                Companyobj.labelcompanyname.Content = emp.EMP_COMPANYNAME;
                Companyobj.txtabout.Text = emp.COMPANYINFO;
                //Companyobj.labelabout.Content = emp.COMPANYINFO;
                Companyobj.labelclient.Content = emp.CLIENT;
                Companyobj.labelcontact.Content = emp.EMP_CONTACT;
                Companyobj.labelwebsite.Content = emp.WEBSITE;

                Companyobj.Show();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void lbFinance_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            try
            {
                string company = (lbFinance.SelectedItem as ListBoxItem).Content.ToString();
                ViewCompanyProfile Companyobj = new ViewCompanyProfile();
                BussinessRules balobj = new BussinessRules();
                Employer emp = balobj.GetCompanyDetails(company);
                //Companyobj.labelcompanyname.Content = emp.EMP_EMAILID;
                Companyobj.labelcompanyname.Content = emp.EMP_COMPANYNAME;
                Companyobj.txtabout.Text = emp.COMPANYINFO;
                //Companyobj.labelabout.Content = emp.COMPANYINFO;
                Companyobj.labelclient.Content = emp.CLIENT;
                Companyobj.labelcontact.Content = emp.EMP_CONTACT;
                Companyobj.labelwebsite.Content = emp.WEBSITE;

                Companyobj.Show();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
