﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using RecruitmentBusinessAccessLayer;
using RecruitmentEntities;
using RecruitmentExceptions;
using System.Windows.Media.Imaging;
using System.Windows.Media;

namespace RecruitmentPresentationLayer
{
    /// <summary>
    /// Interaction logic for JobseekerHomePage.xaml
    /// </summary>
    public partial class JobseekerHomePage : Window
    {
       
        public JobseekerHomePage()
        {
            InitializeComponent();
        }

        private void button_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                BussinessRules balObj = new BussinessRules();
                JobseekerProfile jsObj = new JobseekerProfile();
                jsObj.txtEmail.Text = lblWelcome.Content.ToString();

                JobSeeker js = balObj.GetSeekerDetails(lblWelcome.Content.ToString());
                if (js==null)
                {
                    
                    jsObj.txtfname.Text="";
                    jsObj.txtlname.Text="";
                    jsObj.calDOB.Text="01/08/2018";
                    jsObj.txtMobile.Text="";
                    jsObj.lblphoto.Content="";
                    jsObj.cbHSCBoard.Text="";
                    jsObj.txtHscPer.Text="";
                    jsObj.txtHscYear.Text="";
                    jsObj.cbSscBoard.Text="";
                    jsObj.txtSscPer.Text="";
                    jsObj.txtSscYear.Text="";
                    jsObj.cbUGUniv.Text="";
                    jsObj.txtUgPer.Text="";
                    jsObj.txtUGYear.Text="";
                    jsObj.txtExp.Text="";
                    jsObj.skillsList.Items.Clear();
                    
                    jsObj.lblresume.Content="";
                }
                else
                {

                    //txtEmailId.Text = empobj.EMP_EMAILID;
                    jsObj.txtfname.Text = js.FIRSTNAME;
                    jsObj.txtlname.Text = js.LASTNAME;
                    jsObj.calDOB.Text = Convert.ToString(js.DOB);
                    jsObj.txtMobile.Text = Convert.ToString(js.JS_CONTACT);
                    jsObj.lblphoto.Content = js.PHOTO;
                    jsObj.cbHSCBoard.Text = js.HSC_BOARD;
                    jsObj.txtHscPer.Text = Convert.ToString(js.HSC_PERCENTAGE); ;
                    jsObj.txtHscYear.Text = Convert.ToString(js.HSC_YOP); ;
                    jsObj.cbSscBoard.Text = js.SSC_BOARD;
                    jsObj.txtSscPer.Text = Convert.ToString(js.SSC_PERCENTAGE); ;
                    jsObj.txtSscYear.Text = Convert.ToString(js.SSC_YOP); ;
                    jsObj.cbUGUniv.Text = js.UG_UNIVERSITY;
                    jsObj.txtUgPer.Text = Convert.ToString(js.UG_PERCENTAGE); ;
                    jsObj.txtUGYear.Text = Convert.ToString(js.UG_YOP); ;
                    jsObj.txtExp.Text = Convert.ToString(js.JS_EXPERIENCE); ;
                    

                    jsObj.lblresume.Content =js.RESUME;
                }
                jsObj.Show();
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void logoutButton_Click(object sender, RoutedEventArgs e)
        {
            
            MainWindow obj = new MainWindow();
            obj.Show();
            this.Close();
        }

        private void btnSearchJobs_Click(object sender, RoutedEventArgs e)
        {
            string searchText = txtSearch.Text;
            string searchParam = comboParam.Text;

            if (searchParam == "Location" || searchParam == "Designation")
            {
                BussinessRules balObj = new BussinessRules();
                List<Job> jobs = balObj.searchJobs(searchText, searchParam);

                if (jobs != null)
                {
                    dataGrid.ItemsSource = jobs;
                    if (!dataGrid.HasItems)
                        MessageBox.Show("We couldn't find Jobs that match the criteria specified");
                }
                else
                {
                    throw new RecruitmentException("No jobs found");
                }
            }
            if (searchParam == "SkillSet")
            {
                try
                {
                    string jsID = lblWelcome.Content.ToString();
                    List<Job> jobList = BussinessRules.SearchJobBLFor(jsID);
                    dataGrid.ItemsSource = jobList;
                    if (!dataGrid.HasItems)
                        MessageBox.Show("We couldn't find Jobs that match the criteria specified");
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
            if (searchParam == "Experience")
            {
                try
                {
                    BussinessRules balObj = new BussinessRules();
                    string jsID = lblWelcome.Content.ToString();
                    
                    List<Job> jobList = balObj.searchJobsByExpBAL(jsID);
                    dataGrid.ItemsSource = jobList;
                    if (!dataGrid.HasItems)
                        MessageBox.Show("We couldn't find Jobs that match the criteria specified");
                   
                }
                catch (Exception ex)
                {
                    MessageBox.Show("We are unable to retrieve Jobs.. \nPlease check the details or try again Later");
                }
            }
        }

        private void button1_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                var obj = (Job)dataGrid.SelectedItem;
                ViewCompanyProfile Companyobj = new ViewCompanyProfile();
                BussinessRules balobj = new BussinessRules();
                Employer emp = balobj.GetCompanyDetails(obj.JOB_COMPANYNAME);
                //Companyobj.labelcompanyname.Content = emp.EMP_EMAILID;
                Companyobj.labelcompanyname.Content = emp.EMP_COMPANYNAME;
                Companyobj.txtabout.Text = emp.COMPANYINFO;
                //Companyobj.labelabout.Content = emp.COMPANYINFO;
                Companyobj.labelclient.Content = emp.CLIENT;
                Companyobj.labelcontact.Content = emp.EMP_CONTACT;
                Companyobj.labelwebsite.Content = emp.WEBSITE;

                Companyobj.Show();
            }
            catch (InvalidCastException ex)
            {
                MessageBox.Show("No company selected...");
            }
            
            

            //MessageBox.Show(obj.JOB_COMPANYNAME.ToString());
        }

        private void ListBoxItem_Selected(object sender, RoutedEventArgs e)
        {
            
        }

        private void ListBoxItem_Selected_1(object sender, RoutedEventArgs e)
        {
            
        }

        private void lbIT_MouseDoubleClick(object sender, System.Windows.Input.MouseButtonEventArgs e)
        {
            try
            {
                string company = (lbIT.SelectedItem as ListBoxItem).Content.ToString();
                ViewCompanyProfile Companyobj = new ViewCompanyProfile();
                BussinessRules balobj = new BussinessRules();
                Employer emp = balobj.GetCompanyDetails(company);
                //Companyobj.labelcompanyname.Content = emp.EMP_EMAILID;
                Companyobj.labelcompanyname.Content = emp.EMP_COMPANYNAME;
                Companyobj.txtabout.Text = emp.COMPANYINFO;
                //Companyobj.labelabout.Content = emp.COMPANYINFO;
                Companyobj.labelclient.Content = emp.CLIENT;
                Companyobj.labelcontact.Content = emp.EMP_CONTACT;
                Companyobj.labelwebsite.Content = emp.WEBSITE;

                Companyobj.Show();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void lbSales_MouseDoubleClick(object sender, System.Windows.Input.MouseButtonEventArgs e)
        {
            try
            {
                string company = (lbSales.SelectedItem as ListBoxItem).Content.ToString();
                ViewCompanyProfile Companyobj = new ViewCompanyProfile();
                BussinessRules balobj = new BussinessRules();
                Employer emp = balobj.GetCompanyDetails(company);
                //Companyobj.labelcompanyname.Content = emp.EMP_EMAILID;
                Companyobj.labelcompanyname.Content = emp.EMP_COMPANYNAME;
                Companyobj.txtabout.Text = emp.COMPANYINFO;
                //Companyobj.labelabout.Content = emp.COMPANYINFO;
                Companyobj.labelclient.Content = emp.CLIENT;
                Companyobj.labelcontact.Content = emp.EMP_CONTACT;
                Companyobj.labelwebsite.Content = emp.WEBSITE;

                Companyobj.Show();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void lbMedical_MouseDoubleClick(object sender, System.Windows.Input.MouseButtonEventArgs e)
        {
            try
            {
                string company = (lbMedical.SelectedItem as ListBoxItem).Content.ToString();
                ViewCompanyProfile Companyobj = new ViewCompanyProfile();
                BussinessRules balobj = new BussinessRules();
                Employer emp = balobj.GetCompanyDetails(company);
                //Companyobj.labelcompanyname.Content = emp.EMP_EMAILID;
                Companyobj.labelcompanyname.Content = emp.EMP_COMPANYNAME;
                Companyobj.txtabout.Text = emp.COMPANYINFO;
                //Companyobj.labelabout.Content = emp.COMPANYINFO;
                Companyobj.labelclient.Content = emp.CLIENT;
                Companyobj.labelcontact.Content = emp.EMP_CONTACT;
                Companyobj.labelwebsite.Content = emp.WEBSITE;

                Companyobj.Show();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void lbFinance_MouseDoubleClick(object sender, System.Windows.Input.MouseButtonEventArgs e)
        {
            try
            {
                string company = (lbFinance.SelectedItem as ListBoxItem).Content.ToString();
                ViewCompanyProfile Companyobj = new ViewCompanyProfile();
                BussinessRules balobj = new BussinessRules();
                Employer emp = balobj.GetCompanyDetails(company);
                //Companyobj.labelcompanyname.Content = emp.EMP_EMAILID;
                Companyobj.labelcompanyname.Content = emp.EMP_COMPANYNAME;
                Companyobj.txtabout.Text = emp.COMPANYINFO;
                //Companyobj.labelabout.Content = emp.COMPANYINFO;
                Companyobj.labelclient.Content = emp.CLIENT;
                Companyobj.labelcontact.Content = emp.EMP_CONTACT;
                Companyobj.labelwebsite.Content = emp.WEBSITE;

                Companyobj.Show();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnviewprofile_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                 
                ViewJobSeekerProfile profilewindowobj = new ViewJobSeekerProfile();
                BussinessRules balobj = new BussinessRules();
                JobSeeker seeker = balobj.GetSeekerDetails(lblWelcome.Content.ToString());
                profilewindowobj.labelfirstname.Content = seeker.FIRSTNAME;
                profilewindowobj.labellastname.Content = seeker.LASTNAME;
                profilewindowobj.labeldob.Content = seeker.DOB;
                profilewindowobj.labelcontact.Content = seeker.JS_CONTACT;
                profilewindowobj.labelhscboard.Content = seeker.HSC_BOARD;
                profilewindowobj.labelhscperc.Content = seeker.HSC_PERCENTAGE;
                profilewindowobj.labelhscboard.Content = seeker.HSC_BOARD;
                profilewindowobj.labelhscperc.Content = seeker.HSC_PERCENTAGE;
                profilewindowobj.labelhscyop.Content = seeker.HSC_YOP;
                profilewindowobj.labelsscboard.Content = seeker.SSC_BOARD;
                profilewindowobj.labelsscperc.Content = seeker.SSC_PERCENTAGE;
                profilewindowobj.labelsscyop.Content = seeker.SSC_YOP;
                profilewindowobj.txtugboard.Text = seeker.UG_UNIVERSITY;
                profilewindowobj.labelugperc.Content = seeker.UG_PERCENTAGE;
                profilewindowobj.labelugyop.Content = seeker.UG_YOP;
                profilewindowobj.labelexp.Content = seeker.JS_EXPERIENCE;
                profilewindowobj.txtskills.Text = seeker.JS_SKILLS;
                profilewindowobj.labelresume.Content = seeker.RESUME;
                ImageSource imageSource = new BitmapImage(new Uri(seeker.PHOTO));
                profilewindowobj.image.Source = imageSource;

                profilewindowobj.Show();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
