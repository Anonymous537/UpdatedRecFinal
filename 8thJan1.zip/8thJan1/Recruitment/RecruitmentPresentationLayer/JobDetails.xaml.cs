﻿using System;
using System.Collections.Generic;

using System.Windows;
using System.Windows.Controls;
using RecruitmentBusinessAccessLayer;
using RecruitmentEntities;
using RecruitmentExceptions;

namespace RecruitmentPresentationLayer
{
    /// <summary>
    /// Interaction logic for JobDetails.xaml
    /// </summary>
    public partial class JobDetails : Window
    {

        List<string> skillsFinance = new List<string> {"Interpersonal skills", "Ability to communicate","Financial reporting" };
        List<string> skillsIT = new List<string> {"Problem Solving skills","Web development","Database designing","Application Development" };
        List<string> skillsSales = new List<string> { "Communication", "Strategic Prospecting", "Time Management", "Buyer-Seller Agreement" };

        List<string> designationFinance = new List<string> {"Accountant", "Accounting Clerk","Auditor" ,"Chief Financial Officer","Financial Analyst"};
        List<string> designationIT = new List<string> { "Programmer", "Programmer Analyst", "Security Specialist", "Senior Applications Engineer",
                                                        "Senior Database Administrator","Senior Network Architect",
                                                        "Senior Network Engineer","Senior Network System Administrator"};
        List<string> designationSales = new List<string> { "Sales Representative", "Sales Representative", "Sales Consultant", "Sales Agent" };

        public JobDetails()
        {
            InitializeComponent();
            //try
            //{
            //    BussinessRules blObj = new BussinessRules();
            //    int jobId = blObj.getJobID();
            //    if (jobId != 0)
            //        txtjobId.Text = jobId.ToString();
            //    else
            //        throw new RecruitmentException("Couldn't retrieve job id");
            //}
            //catch (RecruitmentException ex)
            //{
            //    MessageBox.Show(ex.Message);
            //}
        }

        private void btnaddjob_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                Job newJob = new Job();

                newJob.JOB_COMPANYNAME = txtCompanyName.Text;
                newJob.JOB_CATEGORY = comboCategory.Text;
                newJob.JOB_SKILLS ="";
                foreach (string item in skillsList.SelectedItems)
                {
                    newJob.JOB_SKILLS += item + ",";
                }
                newJob.DESIGNATION = comboDesignation.Text;
                newJob.JOB_LOCATION = txtLocation.Text;
                newJob.JOB_EXPERIENCE = Convert.ToInt32(txtExperience.Text);
                newJob.NO_OF_POSITIONS = Convert.ToInt32(txtOpening.Text);

                BussinessRules balObj = new BussinessRules();
                bool added = balObj.addJob(newJob);
                if (added)
                {
                    MessageBox.Show("Job Added successfully");
                    this.Close();
                }
                else
                    throw new RecruitmentException("Job cannot be added");
            }
            catch(RecruitmentException ex)
            {
               MessageBox.Show(ex.Message);
            }


        }

        private void comboCategory_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            try
            {
                if (comboCategory.SelectedIndex==1)
                {
                    skillsList.ItemsSource = skillsFinance;
                    comboDesignation.ItemsSource = designationFinance;
                }
                else if (comboCategory.SelectedIndex==2)
                {
                    skillsList.ItemsSource = skillsIT;
                    comboDesignation.ItemsSource = designationIT;
                }
                else if (comboCategory.SelectedIndex == 3)
                {
                    skillsList.ItemsSource = skillsSales;
                    comboDesignation.ItemsSource = designationSales;
                }

            }
           catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

 
    }
}
