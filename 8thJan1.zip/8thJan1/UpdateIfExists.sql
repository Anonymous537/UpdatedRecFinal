ALTER PROCEDURE [dbo].[uspAddEmployer] 
	
	(
	@EmailID varchar(30),
	@CompanyName varchar(50),
	@CompanyInfo ntext,
	@Client varchar(100),
	@EmpContact bigint,
	@Website varchar(20)
	)
	
AS
IF EXISTS (Select company_name from Employer_details where company_name=@companyName)
BEGIN
UPDATE Employer_details 
SET company_info=@CompanyInfo,client=@Client,contact_no=@EmpContact,website=@Website 
WHERE company_name=@CompanyName 
END
ELSE
	insert into Employer_details Values(@EmailID, @CompanyName, @CompanyInfo, @Client, @EmpContact, @Website)

exec uspAddEmployer 'career@capg.com','CapG','Xyz','Google','9898989898','www.google.com'