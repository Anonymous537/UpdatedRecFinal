﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RecruitmentEntities
{
    public class Employer
    {
        public string EMP_EMAILID { get; set; }
        public string EMP_COMPANYNAME { get; set; }
        public string COMPANYINFO { get; set; }
        public string CLIENT { get; set; }
        public long EMP_CONTACT { get; set; }
        public string WEBSITE { get; set; }
    }
}
