﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RecruitmentExceptions
{
    public class RecruitmentException : ApplicationException
    {
            public RecruitmentException()
            {

            }

            public RecruitmentException(string message) : base(message)
            {
                
            }

            public RecruitmentException(string message, Exception innerException) : base(message, innerException)
            {

            }
        }
    }

