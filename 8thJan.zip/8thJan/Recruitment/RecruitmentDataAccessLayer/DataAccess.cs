﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using RecruitmentExceptions;
using RecruitmentEntities;
using System.Data.Common;
using System.Data;

namespace RecruitmentDataAccessLayer
{
    public class DataAccess
    {
        public string authenticateUserDAL(string username, string password)
        {
            string utype = null;

            try
            {
                DbCommand command = DataConnection.CreateCommand();
                command.CommandType = CommandType.Text;
                command.CommandText = "select user_type from Login_Credentials where email_id='"+username+"' and user_password='"+password+"';";

                DataTable dt = DataConnection.ExecuteSelectCommand(command);
                if (dt.Rows.Count > 0)
                {
                    utype = (string)dt.Rows[0][0];
                }
                return utype;
            }
            catch(Exception ex)
            {
                throw new RecruitmentException(ex.Message);
            }
        }



        public string getcnameDAL(string email)
        {
            string company = null;
            try
            {
                DbCommand com = DataConnection.CreateCommand();
                com.CommandType = CommandType.Text;
                com.CommandText = "select company_name from employer_details where email_id='" + email + "';";

                DataTable dt = DataConnection.ExecuteSelectCommand(com);
                if (dt.Rows.Count > 0)
                {
                    company = (string)dt.Rows[0][0];
                }
            }
            catch(Exception ex)
            {
                throw ex;
            }
            return company;
        }

        public bool addJobSeekerDAL(JobSeeker jsObj)
        {
            bool jobSeekeradded = false;
            try
            {
                DbCommand command = DataConnection.CreateCommand();
                command.CommandText = "addJobSeeker";

                DbParameter param = command.CreateParameter();

                param.ParameterName = "@email_id";
                param.DbType = DbType.String;
                param.Value = jsObj.JS_EMAILID;
                command.Parameters.Add(param);

                param = command.CreateParameter();
                param.ParameterName = "@fname";
                param.DbType = DbType.String;
                param.Value = jsObj.FIRSTNAME;
                command.Parameters.Add(param);

                param = command.CreateParameter();
                param.ParameterName = "@lname";
                param.DbType = DbType.String;
                param.Value = jsObj.LASTNAME;
                command.Parameters.Add(param);

                param = command.CreateParameter();
                param.ParameterName = "@dob";
                param.DbType = DbType.DateTime;
                param.Value = jsObj.DOB.Date;
                command.Parameters.Add(param);

                param = command.CreateParameter();
                param.ParameterName = "@mobile_no";
                param.DbType = DbType.Int64;
                param.Value = jsObj.JS_CONTACT;
                command.Parameters.Add(param);

                param = command.CreateParameter();
                param.ParameterName = "@photo";
                param.DbType = DbType.String;
                param.Value = jsObj.PHOTO;
                command.Parameters.Add(param);

                param = command.CreateParameter();
                param.ParameterName = "@hsc_board";
                param.DbType = DbType.String;
                param.Value = jsObj.HSC_BOARD;
                command.Parameters.Add(param);

                param = command.CreateParameter();
                param.ParameterName = "@hsc_percentage";
                param.DbType = DbType.Decimal;
                param.Value = jsObj.HSC_PERCENTAGE;
                command.Parameters.Add(param);

                param = command.CreateParameter();
                param.ParameterName = "@hsc_yop";
                param.DbType = DbType.Int32;
                param.Value = jsObj.HSC_YOP;
                command.Parameters.Add(param);

                param = command.CreateParameter();
                param.ParameterName = "@ssc_board";
                param.DbType = DbType.String;
                param.Value = jsObj.SSC_BOARD;
                command.Parameters.Add(param);

                param = command.CreateParameter();
                param.ParameterName = "@ssc_percentage";
                param.DbType = DbType.Decimal;
                param.Value = jsObj.SSC_PERCENTAGE;
                command.Parameters.Add(param);

                param = command.CreateParameter();
                param.ParameterName = "@ssc_yop";
                param.DbType = DbType.Int32;
                param.Value = jsObj.SSC_YOP;
                command.Parameters.Add(param);

                param = command.CreateParameter();
                param.ParameterName = "@ug_university";
                param.DbType = DbType.String;
                param.Value = jsObj.UG_UNIVERSITY;
                command.Parameters.Add(param);

                param = command.CreateParameter();
                param.ParameterName = "@ug_percentage";
                param.DbType = DbType.Decimal;
                param.Value = jsObj.UG_PERCENTAGE;
                command.Parameters.Add(param);

                param = command.CreateParameter();
                param.ParameterName = "@ug_yop";
                param.DbType = DbType.Int32;
                param.Value = jsObj.UG_YOP;
                command.Parameters.Add(param);

                param = command.CreateParameter();
                param.ParameterName = "@experience";
                param.DbType = DbType.String;
                param.Value = jsObj.JS_EXPERIENCE;
                command.Parameters.Add(param);

                param = command.CreateParameter();
                param.ParameterName = "@skills";
                param.DbType = DbType.String;
                param.Value = jsObj.JS_SKILLS;
                command.Parameters.Add(param);

                param = command.CreateParameter();
                param.ParameterName = "@resume";
                param.DbType = DbType.String;
                param.Value = jsObj.RESUME;
                command.Parameters.Add(param);

                int affectedrows = DataConnection.ExecuteNonQueryCommand(command);
                if (affectedrows > 0)
                    jobSeekeradded = true;

            }
            catch (Exception ex)
            {
                throw ex;
            }
            return jobSeekeradded;
        }

        public List<JobSeeker> searchJSByExpDAL(int jobid)
        {
            List<JobSeeker> searchedJobseekers = new List<JobSeeker>();
            try
            {
                DbCommand command = DataConnection.CreateCommand();
                command.CommandText = "GetExperience";

                DbParameter param = command.CreateParameter();
                param.ParameterName = "@JobID";
                param.DbType = DbType.Int32;
                param.Value = jobid;
                command.Parameters.Add(param);

               

                DataTable dt = DataConnection.ExecuteSelectCommand(command);

                if (dt.Rows.Count > 0)
                {
                    JobSeeker newJobseeker = null; 

                    for (int index = 0; index < dt.Rows.Count; index++)
                    {
                        newJobseeker= new JobSeeker();
                        newJobseeker.JS_EMAILID = Convert.ToString(dt.Rows[index][0]);
                        newJobseeker.FIRSTNAME = Convert.ToString(dt.Rows[index][1]);
                        newJobseeker.LASTNAME = Convert.ToString(dt.Rows[index][2]);
                        newJobseeker.JS_EXPERIENCE = Convert.ToInt32(dt.Rows[index][15]);
                        newJobseeker.JS_SKILLS = Convert.ToString(dt.Rows[index][16]);
                        

                        searchedJobseekers.Add(newJobseeker);
                    }
                }
                return searchedJobseekers;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public List<Job> searchJobsDAL(string searchText, string searchParam)
        {
            List<Job> searchedJobs = new List<Job>();
            try
            {
                DbCommand command = DataConnection.CreateCommand();
                command.CommandText = "searchJobs";

                DbParameter param = command.CreateParameter();
                param.ParameterName = "@searchText";
                param.DbType = DbType.String;
                param.Value = searchText;
                command.Parameters.Add(param);

                param = command.CreateParameter();
                param.ParameterName = "@searchParam";
                param.DbType = DbType.String;
                param.Value = searchParam;
                command.Parameters.Add(param);

                DataTable dt = DataConnection.ExecuteSelectCommand(command);
                
                if (dt.Rows.Count>0)
                {
                    Job newJob = null;

                    for(int index=0;index<dt.Rows.Count;index++)
                    {
                        newJob = new Job();
                        newJob.JOB_COMPANYNAME = Convert.ToString(dt.Rows[index][0]);
                        newJob.JOBID = Convert.ToInt32(dt.Rows[index][1]);
                        newJob.JOB_CATEGORY = Convert.ToString(dt.Rows[index][2]);
                        newJob.JOB_SKILLS = Convert.ToString(dt.Rows[index][3]);
                        newJob.DESIGNATION = Convert.ToString(dt.Rows[index][4]);
                        newJob.JOB_LOCATION = Convert.ToString(dt.Rows[index][5]);
                        newJob.JOB_EXPERIENCE = Convert.ToInt32(dt.Rows[index][6]);
                        newJob.NO_OF_POSITIONS = Convert.ToInt32(dt.Rows[index][7]);
                        
                        searchedJobs.Add(newJob);
                    }
                }
                return searchedJobs;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }


        public List<Job> searchJobsByExpDAL(string jsId)
        {
            List<Job> searchedJobs = new List<Job>();
            try
            {
                DbCommand command = DataConnection.CreateCommand();
                command.CommandText = "getJobsByExp";

                DbParameter param = command.CreateParameter();
                param.ParameterName = "@jsId";
                param.DbType = DbType.String;
                param.Value = jsId;
                command.Parameters.Add(param);

                DataTable dt = DataConnection.ExecuteSelectCommand(command);

                if (dt.Rows.Count > 0)
                {
                    Job newJob = null;

                    for (int index = 0; index < dt.Rows.Count; index++)
                    {
                        newJob = new Job();
                        newJob.JOB_COMPANYNAME = Convert.ToString(dt.Rows[index][0]);
                        newJob.JOBID = Convert.ToInt32(dt.Rows[index][1]);
                        newJob.JOB_CATEGORY = Convert.ToString(dt.Rows[index][2]);
                        newJob.JOB_SKILLS = Convert.ToString(dt.Rows[index][3]);
                        newJob.DESIGNATION = Convert.ToString(dt.Rows[index][4]);
                        newJob.JOB_LOCATION = Convert.ToString(dt.Rows[index][5]);
                        newJob.JOB_EXPERIENCE = Convert.ToInt32(dt.Rows[index][6]);
                        newJob.NO_OF_POSITIONS = Convert.ToInt32(dt.Rows[index][7]);

                        searchedJobs.Add(newJob);
                    }
                }
                return searchedJobs;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public bool addJobDAL(Job job)
        {
            bool jobAdded = false;
            try
            {
                DbCommand command = DataConnection.CreateCommand();
                command.CommandText = "addJob";

                DbParameter param = command.CreateParameter();
                param.ParameterName = "@companyname";
                param.DbType = DbType.String;
                param.Value = job.JOB_COMPANYNAME;
                command.Parameters.Add(param);


                param = command.CreateParameter();
                param.ParameterName = "@category";
                param.DbType = DbType.String;
                param.Value = job.JOB_CATEGORY;
                command.Parameters.Add(param);


                param = command.CreateParameter();
                param.ParameterName = "@skills";
                param.DbType = DbType.String;
                param.Value = job.JOB_SKILLS;
                command.Parameters.Add(param);

                param = command.CreateParameter();
                param.ParameterName = "@designation";
                param.DbType = DbType.String;
                param.Value = job.DESIGNATION;
                command.Parameters.Add(param);

                param = command.CreateParameter();
                param.ParameterName = "@location";
                param.DbType = DbType.String;
                param.Value = job.JOB_LOCATION;
                command.Parameters.Add(param);

                param = command.CreateParameter();
                param.ParameterName = "@exp";
                param.DbType = DbType.Int16;
                param.Value = job.JOB_EXPERIENCE;
                command.Parameters.Add(param);

                param = command.CreateParameter();
                param.ParameterName = "@openings";
                param.DbType = DbType.Int32;
                param.Value = job.NO_OF_POSITIONS;
                command.Parameters.Add(param);

                int affectedRows = DataConnection.ExecuteNonQueryCommand(command);

                if (affectedRows > 0)
                    jobAdded = true;
            }
            catch (DbException ex)
            {
                string errormessage;

                switch (ex.ErrorCode)
                {
                    case -2146232060:
                        errormessage = "Database Does NotExists Or AccessDenied";
                        break;
                    default:
                        errormessage = ex.Message;
                        break;
                }
                throw new RecruitmentException(errormessage);
            }
            return jobAdded;
        }

        //public int getJobIdDAL()
        //{
        //    int id = 0;
        //    try
        //    {
        //        DbCommand com = DataConnection.CreateCommand();
        //        com.CommandText = "getJobId";

        //        DbParameter param = com.CreateParameter();
        //        param.ParameterName = "@jobId";
        //        param.DbType = DbType.Int32;
        //        param.Direction = ParameterDirection.Output;
        //        com.Parameters.Add(param);

        //        DataTable dt = new DataTable();
        //        dt=DataConnection.ExecuteSelectCommand(com);
        //        if(dt.Rows.Count>0)
        //        {
        //            string dvalue = (string)dt.Rows[0][0];
        //            if (dvalue.Equals("NULL"))
        //                id = 0;
        //        }
        //        id = Convert.ToInt32(param.Value);

        //    }
        //    catch(Exception ex)
        //    {
        //        throw ex;
        //    }
        //    return id+1;
        //}

        public bool AddEmployerDAL(Employer employer)
        {
            bool employerAdded = false;
            try
            {
                DbCommand command = DataConnection.CreateCommand();
                command.CommandText = "uspAddEmployer";

                DbParameter param = command.CreateParameter();
                param.ParameterName = "@EmailID";
                param.DbType = DbType.String;
                param.Value = employer.EMP_EMAILID;
                command.Parameters.Add(param);


                param = command.CreateParameter();
                param.ParameterName = "@CompanyName";
                param.DbType = DbType.String;
                param.Value = employer.EMP_COMPANYNAME;
                command.Parameters.Add(param);


                param = command.CreateParameter();
                param.ParameterName = "@CompanyInfo";
                param.DbType = DbType.String;
                param.Value = employer.COMPANYINFO;
                command.Parameters.Add(param);

                param = command.CreateParameter();
                param.ParameterName = "@Client";
                param.DbType = DbType.String;
                param.Value = employer.CLIENT;
                command.Parameters.Add(param);

                param = command.CreateParameter();
                param.ParameterName = "@EmpContact";
                param.DbType = DbType.Decimal;
                param.Value = employer.EMP_CONTACT;
                command.Parameters.Add(param);

                param = command.CreateParameter();
                param.ParameterName = "@Website";
                param.DbType = DbType.String;
                param.Value = employer.WEBSITE;
                command.Parameters.Add(param);

                int affectedRows = DataConnection.ExecuteNonQueryCommand(command);

                if (affectedRows > 0)
                    employerAdded = true;
            }
            catch (DbException ex)
            {
                string errormessage;

                switch (ex.ErrorCode)
                {
                    case -2146232060:
                        errormessage = "Database Does NotExists Or AccessDenied";
                        break;
                    default:
                        errormessage = ex.Message;
                        break;
                }
                throw new RecruitmentException(errormessage);
            }
            return employerAdded;
        }

        public bool addUserDAL(string username, string password, string user_type)
        {
            bool useradded = false;

            try
            {
                DbCommand command = DataConnection.CreateCommand();
                command.CommandText = "addUser";

                DbParameter param = command.CreateParameter();

                param.ParameterName = "@username";
                param.DbType = DbType.String;
                param.Value = username;
                command.Parameters.Add(param);

                param = command.CreateParameter();
                param.ParameterName = "@password";
                param.DbType = DbType.String;
                param.Value = password;
                command.Parameters.Add(param);

                param = command.CreateParameter();
                param.ParameterName = "@usertype";
                param.DbType = DbType.String;
                param.Value = user_type;
                command.Parameters.Add(param);

                int affectedrows = DataConnection.ExecuteNonQueryCommand(command);
                if (affectedrows > 0)
                    useradded = true;

            }
            catch (Exception ex)
            {
                throw ex;
            }
            return useradded;
        }
        public Employer GetCompanyDetails(string companyName)
        {
            Employer obj = new Employer();
            try
            {
                DbCommand command = DataConnection.CreateCommand();
                command.CommandText = "GetCompanyDetails";

                DbParameter param = command.CreateParameter();
                param.ParameterName = "@companyName";
                param.DbType = DbType.String;
                param.Value = companyName;
                command.Parameters.Add(param);

                DataTable dt = DataConnection.ExecuteSelectCommand(command);

                if (dt.Rows.Count > 0)
                {
                   

                    for (int index = 0; index < dt.Rows.Count; index++)
                    {
                        obj.EMP_EMAILID = Convert.ToString(dt.Rows[index][0]);
                        obj.EMP_COMPANYNAME = Convert.ToString(dt.Rows[index][1]);
                        obj.COMPANYINFO = Convert.ToString(dt.Rows[index][2]);
                        obj.CLIENT = Convert.ToString(dt.Rows[index][3]);
                        obj.EMP_CONTACT = Convert.ToInt64(dt.Rows[index][4]);
                        obj.WEBSITE = Convert.ToString(dt.Rows[index][5]);
                    }
                }
                return obj;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public JobSeeker GetSeekerDetails(string email)
        {
            JobSeeker jsobj = new JobSeeker();
            try
            {
                DbCommand command = DataConnection.CreateCommand();
                command.CommandText = "GetSeekerDetails";

                DbParameter param = command.CreateParameter();
                param.ParameterName = "@email_id";
                param.DbType = DbType.String;
                param.Value = email;
                command.Parameters.Add(param);

                DataTable dt = DataConnection.ExecuteSelectCommand(command);

                if (dt.Rows.Count > 0)
                {


                    for (int index = 0; index < dt.Rows.Count; index++)
                    {
                        jsobj.JS_EMAILID = Convert.ToString(dt.Rows[index][0]);
                        jsobj.FIRSTNAME = Convert.ToString(dt.Rows[index][1]);
                        jsobj.LASTNAME = Convert.ToString(dt.Rows[index][2]);
                        jsobj.DOB = Convert.ToDateTime(dt.Rows[index][3]);
                        jsobj.JS_CONTACT = Convert.ToInt64(dt.Rows[index][4]);
                        jsobj.PHOTO = Convert.ToString(dt.Rows[index][5]);
                        jsobj.HSC_BOARD = Convert.ToString(dt.Rows[index][6]);
                        jsobj.HSC_PERCENTAGE = Convert.ToInt32(dt.Rows[index][7]);
                        jsobj.HSC_YOP = Convert.ToInt32(dt.Rows[index][8]);
                        jsobj.SSC_BOARD = Convert.ToString(dt.Rows[index][9]);
                        jsobj.SSC_PERCENTAGE = Convert.ToInt32(dt.Rows[index][10]);
                        jsobj.SSC_YOP = Convert.ToInt32(dt.Rows[index][11]);
                        jsobj.UG_UNIVERSITY = Convert.ToString(dt.Rows[index][12]);
                        jsobj.UG_PERCENTAGE = Convert.ToInt32(dt.Rows[index][13]);
                        jsobj.UG_YOP = Convert.ToInt32(dt.Rows[index][14]);
                        jsobj.JS_EXPERIENCE = Convert.ToInt32(dt.Rows[index][15]);
                        jsobj.JS_SKILLS = Convert.ToString(dt.Rows[index][16]);
                        jsobj.RESUME = Convert.ToString(dt.Rows[index][17]);
                    }
                }
                return jsobj;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public List<int> getJobIdDAL(string company)
        {
            List<int> searchedJobId = new List<int>();
            int id = 0;
            try
            {
                DbCommand command = DataConnection.CreateCommand();
                command.CommandText = "GetJobs";

                DbParameter param = command.CreateParameter();
                param.ParameterName = "@CompanyName";
                param.DbType = DbType.String;
                param.Value = company;
                command.Parameters.Add(param);

                

                DataTable dt = DataConnection.ExecuteSelectCommand(command);

                if (dt.Rows.Count > 0)
                {
                    
                    for (int index = 0; index < dt.Rows.Count; index++)
                    {
                        id = Convert.ToInt32(dt.Rows[index][0]);
                        searchedJobId.Add(id);
                    }
                }
                return searchedJobId;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        

        ///////////////////////////////////////////To be used by Jobseeker/////////////////////////////

        public List<string> GetJSSkills(string searchJSID)//Jobseeker extracts his skillList
        {
            string[] skills = { };
            List<string> skillList = new List<string>();
            string skillString = "";
            JobSeeker searchJS = null;
            try
            {
                DbCommand command = DataConnection.CreateCommand();
                command.CommandText = "GetJobseekerSkills";

                DbParameter param = command.CreateParameter();
                param.ParameterName = "@JobseekerID";
                param.DbType = DbType.String;
                param.Value = searchJSID;
                command.Parameters.Add(param);

                DataTable dataTable = DataConnection.ExecuteSelectCommand(command);
                if (dataTable.Rows.Count > 0)
                {
                    searchJS = new JobSeeker();
                    skillString = (string)dataTable.Rows[0][0];
                }
                skills = skillString.Split(',');
                skillList.AddRange(skills);
                skillList.Sort();
                skillList.RemoveAt(0);
            }
            catch (DbException ex)
            {
                throw new Exception(ex.Message);
            }
            return skillList;
        }

        public List<Job> GetAllJobs()//Jobseeker gets list of all Jobs to filter the skills
        {
            string[] skills = { };
            List<Job> listJob = new List<Job>();
            try
            {
                DbCommand command = DataConnection.CreateCommand();
                command.CommandText = "GetAllJobs";

                DataTable dt = DataConnection.ExecuteSelectCommand(command);
                if (dt.Rows.Count > 0)
                {
                    for (int index = 0; index < dt.Rows.Count; index++)
                    {
                        Job newJob = new Job();
                        newJob.JOB_COMPANYNAME = Convert.ToString(dt.Rows[index][0]);
                        newJob.JOBID = Convert.ToInt32(dt.Rows[index][1]);
                        newJob.JOB_CATEGORY = Convert.ToString(dt.Rows[index][2]);
                        newJob.JOB_SKILLS = Convert.ToString(dt.Rows[index][3]);
                        newJob.DESIGNATION = Convert.ToString(dt.Rows[index][4]);
                        newJob.JOB_LOCATION = Convert.ToString(dt.Rows[index][5]);
                        newJob.JOB_EXPERIENCE = Convert.ToInt32(dt.Rows[index][6]);
                        newJob.NO_OF_POSITIONS = Convert.ToInt32(dt.Rows[index][7]);
                        listJob.Add(newJob);
                    }
                }
            }
            catch (DbException ex)
            {
                throw new Exception(ex.Message);
            }
            return listJob;
        }


        //////////////////////////////////////TO BE USED BY EMPLOYER//////////////////////////////

        public List<string> GetJobSkills(int searchJobID)//Employer gets the skills required by the job into a string
        {
            string[] skills = { };
            List<string> skillListJob = new List<string>();
            Job searchJob = null;
            try
            {
                DbCommand command = DataConnection.CreateCommand();
                command.CommandText = "GetJobSkills";

                DbParameter param = command.CreateParameter();
                param.ParameterName = "@Job_ID";
                param.DbType = DbType.Int32;
                param.Value = searchJobID;
                command.Parameters.Add(param);

                DataTable dataTable = DataConnection.ExecuteSelectCommand(command);
                if (dataTable.Rows.Count > 0)
                {
                    searchJob = new Job();
                    searchJob.JOB_SKILLS = (string)dataTable.Rows[0][0];
                }
                skills = searchJob.JOB_SKILLS.Split(',');
                skillListJob.AddRange(skills);
                skillListJob.Sort();
                skillListJob.RemoveAt(0);

            }
            catch (DbException ex)
            {
                throw new Exception(ex.Message);
            }
            return skillListJob;
        }


        public List<JobSeeker> GetJobseeker() // Get All Jobseekers to search the Jobs
        {
            string[] skills = { };
            List<JobSeeker> listJS = null;
            try
            {
                DbCommand command = DataConnection.CreateCommand();
                command.CommandText = "GetJobseeker";

                DataTable dt = DataConnection.ExecuteSelectCommand(command);
                if (dt.Rows.Count > 0)
                {
                    listJS = new List<JobSeeker>();
                    for (int index = 0; index < dt.Rows.Count; index++)
                    {
                        JobSeeker jsobj = new JobSeeker();
                        jsobj.JS_EMAILID = Convert.ToString(dt.Rows[index][0]);
                        jsobj.FIRSTNAME = Convert.ToString(dt.Rows[index][1]);
                        jsobj.LASTNAME = Convert.ToString(dt.Rows[index][2]);
                        jsobj.DOB = Convert.ToDateTime(dt.Rows[index][3]);
                        jsobj.JS_CONTACT = Convert.ToInt64(dt.Rows[index][4]);
                        jsobj.PHOTO = Convert.ToString(dt.Rows[index][5]);
                        jsobj.HSC_BOARD = Convert.ToString(dt.Rows[index][6]);
                        jsobj.HSC_PERCENTAGE = Convert.ToInt32(dt.Rows[index][7]);
                        jsobj.HSC_YOP = Convert.ToInt32(dt.Rows[index][8]);
                        jsobj.SSC_BOARD = Convert.ToString(dt.Rows[index][9]);
                        jsobj.SSC_PERCENTAGE = Convert.ToInt32(dt.Rows[index][10]);
                        jsobj.SSC_YOP = Convert.ToInt32(dt.Rows[index][11]);
                        jsobj.UG_UNIVERSITY = Convert.ToString(dt.Rows[index][12]);
                        jsobj.UG_PERCENTAGE = Convert.ToInt32(dt.Rows[index][13]);
                        jsobj.UG_YOP = Convert.ToInt32(dt.Rows[index][14]);
                        jsobj.JS_EXPERIENCE = Convert.ToInt32(dt.Rows[index][15]);
                        jsobj.JS_SKILLS = Convert.ToString(dt.Rows[index][16]);
                        jsobj.RESUME = Convert.ToString(dt.Rows[index][17]);
                        listJS.Add(jsobj);
                    }
                }
            }
            catch (DbException ex)
            {
                throw new Exception(ex.Message);
            }
            return listJS;
        }



    }
}

