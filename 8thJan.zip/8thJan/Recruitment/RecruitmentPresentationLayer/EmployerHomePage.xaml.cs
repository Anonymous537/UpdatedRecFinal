﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using RecruitmentBusinessAccessLayer;
using RecruitmentExceptions;
using RecruitmentEntities;
using System.Windows.Media;
using System.Windows.Media.Imaging;

namespace RecruitmentPresentationLayer
{
    /// <summary>
    /// Interaction logic for EmployerHomePage.xaml
    /// </summary>
    public partial class EmployerHomePage : Window
    {
        public EmployerHomePage()
        {
            InitializeComponent();
            
        }

        private void btnAddJob_Click(object sender, RoutedEventArgs e)
        {
            string cname = "";
            string email = lblcompany.Content.ToString();
            try
            {
                JobDetails jdObj = new JobDetails();
                BussinessRules balObj = new BussinessRules();
                    cname = balObj.getCompanyName(email);
                    if (cname != null)
                    jdObj.txtCompanyName.Text = cname;
                    else
                        throw new RecruitmentException("Couldn't retrieve company name");
               
                jdObj.Show();
            }
            catch (RecruitmentException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        //private void btnEditProf_Click(object sender, RoutedEventArgs e)
        //{
        //    EmployerProfile obj = new EmployerProfile();
        //    obj.txtEmailId.Text = lblcompany.Content.ToString();
        //    obj.Show();
        //    //this.Close();
        //}

        private void logoutButton_Click(object sender, RoutedEventArgs e)
        {
            GenericHomePage obj = new GenericHomePage();
            obj.Show();
            this.Close();
            
        }


        private void btnSearchJobs_Click_1(object sender, RoutedEventArgs e)
        {
            string searchParam = comboParam.Text;

            try
            {

                if (searchParam == "Experience")
                {

                    int searchjobId = Convert.ToInt32(comboJobId.Text);

                    BussinessRules balObj = new BussinessRules();
                    List<JobSeeker> seekerList = balObj.searchJSByExp(searchjobId);

                    if (seekerList != null)
                    {

                        dataGrid.ItemsSource = seekerList;
                        for (int i = 3; i < 15; i++)
                        {
                            dataGrid.Columns[i].Visibility = Visibility.Collapsed;
                        }
                        dataGrid.Columns[17].Visibility = Visibility.Collapsed;

                    }
                    else
                    {
                        throw new RecruitmentException("No jobseekers found");
                    }

                }
                if (searchParam == "SkillSet")
                {
                    try
                    {
                        int empID = Convert.ToInt32(comboJobId.SelectedItem);
                        string str = "";
                        List<JobSeeker> jsList = BussinessRules.SearchJSBLFor(Convert.ToInt32(comboJobId.Text));
                        dataGrid.ItemsSource = jsList;
                        foreach (JobSeeker item in jsList)
                        {
                            str = str + "\n" + item.JS_EMAILID;
                        }
                        MessageBox.Show(str);
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message);
                    }
                }

            }
            catch (RecruitmentException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void comboParam_SelectionChanged(object sender, System.Windows.Controls.SelectionChangedEventArgs e)
        {
            if(comboParam.SelectedIndex==0)
            {
                return;
            }
            List<int> jobIdList = new List<int>();
            string email = lblcompany.Content.ToString();
            try
            {
                BussinessRules balObj = new BussinessRules();
                jobIdList = balObj.getJobIdBAL(balObj.getCompanyName(email));

                comboJobId.ItemsSource = jobIdList;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void buttonvieprofile_Click(object sender, RoutedEventArgs e)
        {
            try
            {
            var obj = (JobSeeker)dataGrid.SelectedItem;
            ViewJobSeekerProfile profilewindowobj = new ViewJobSeekerProfile();
            BussinessRules balobj = new BussinessRules();
            JobSeeker seeker = balobj.GetSeekerDetails(obj.JS_EMAILID);
            profilewindowobj.labelfirstname.Content = seeker.FIRSTNAME;
            profilewindowobj.labellastname.Content = seeker.LASTNAME;
            profilewindowobj.labeldob.Content = seeker.DOB;
            profilewindowobj.labelcontact.Content = seeker.JS_CONTACT;
            profilewindowobj.labelhscboard.Content = seeker.HSC_BOARD;
            profilewindowobj.labelhscperc.Content = seeker.HSC_PERCENTAGE;
            profilewindowobj.labelhscboard.Content = seeker.HSC_BOARD;
            profilewindowobj.labelhscperc.Content = seeker.HSC_PERCENTAGE;
            profilewindowobj.labelhscyop.Content = seeker.HSC_YOP;
            profilewindowobj.labelsscboard.Content = seeker.SSC_BOARD;
            profilewindowobj.labelsscperc.Content = seeker.SSC_PERCENTAGE;
            profilewindowobj.labelsscyop.Content = seeker.SSC_YOP;
            profilewindowobj.labelugboard.Content = seeker.UG_UNIVERSITY;
            profilewindowobj.labelugperc.Content = seeker.UG_PERCENTAGE;
            profilewindowobj.labelugyop.Content = seeker.UG_YOP;
            profilewindowobj.labelexp.Content = seeker.JS_EXPERIENCE;
            profilewindowobj.labelskills.Content = seeker.JS_SKILLS;
            profilewindowobj.labelresume.Content = seeker.RESUME;
            ImageSource imageSource = new BitmapImage(new Uri(seeker.PHOTO));
            profilewindowobj.image.Source = imageSource;

            profilewindowobj.Show();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }





        }

        private void btnUpdateProf_Click(object sender, RoutedEventArgs e)
        {
            EmployerProfile obj = new EmployerProfile();
            obj.txtEmailId.Text = lblcompany.Content.ToString();
            obj.Show();
            this.Close();

        }
    }
}
