﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using RecruitmentEntities;
using RecruitmentBusinessAccessLayer;
using RecruitmentExceptions;


namespace RecruitmentPresentationLayer
{
    /// <summary>
    /// Interaction logic for SignUp.xaml
    /// </summary>
    public partial class SignUp : Window
    {
        public SignUp()
        {
            InitializeComponent();
        }

        private void button_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                string username = txtEmail.Text;
                string password = txtPassword.Password;
                string confpassword = txtPasswordConf.Password;
                string utype = null;
                if (radioJobseeker.IsChecked == true)
                    utype = "jobseeker";
                else
                    utype = "employer";
                bool status = false;
                BussinessRules balObj = new BussinessRules();
                    status = balObj.addUser(username, password,confpassword, utype);
                    if (status)
                    {
                        MessageBox.Show("User added successfully.\n Add details to continue");

                        if (utype=="jobseeker")
                        {
                            JobseekerProfile obj = new JobseekerProfile();
                            obj.txtEmail.Text = username;
                            obj.Show();
                            this.Close();
                        }
                        else if (utype == "employer")
                        {
                            EmployerProfile obj = new EmployerProfile();
                            obj.txtEmailId.Text = username;
                            obj.Show();
                            this.Close();
                        }
                        else
                        {
                            MessageBox.Show("Please select a type");
                        }
                    
                    }
                    else
                    {
                        MessageBox.Show("User not added");
                    }
            }
            catch(RecruitmentException ex)
            {
                MessageBox.Show(ex.Message, "Exception", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
    }
}
