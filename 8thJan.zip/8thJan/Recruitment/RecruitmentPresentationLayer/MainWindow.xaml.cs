﻿using System.Windows;
using RecruitmentEntities;
using RecruitmentBusinessAccessLayer;
using RecruitmentExceptions;
using System;

namespace RecruitmentPresentationLayer
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
       
        public MainWindow()
        {
            InitializeComponent();
            
        }

        private void btnLogin_Click(object sender, RoutedEventArgs e)
        {
            BussinessRules balobj = new BussinessRules();
            string username, password;
            try
            {
                username = txtUsername.Text;
                password = txtPassword.Password;
                string usertype = balobj.authenticateUser(username, password);

                if(usertype=="jobseeker")
                {
                    JobseekerHomePage jobObj = new JobseekerHomePage();
                    //JobseekerProfile jsObj = new JobseekerProfile();
                    jobObj.lblWelcome.Content = "Hi "+txtUsername.Text;
                    //jsObj.txtEmail.Text=txtUsername.Text;
                    MainWindow mainObj = new MainWindow();
                    jobObj.Show();
                    this.Close();
                }
                else if (usertype == "employer")
                {
                    EmployerHomePage empObj = new EmployerHomePage();
                    //MainWindow mainObj = new MainWindow();
                    empObj.lblcompany.Content = "Welcome "+txtUsername.Text;
                    
                    empObj.Show();
                    this.Close();
                }
                else
                {
                    MessageBox.Show("Invalid Username or Password.\nPlease enter correct credentials to continue.", "Authentication failure", MessageBoxButton.OK, MessageBoxImage.Error);
                    txtUsername.Text="";
                    txtPassword.Password="";
                }
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            

        }

        private void btnRegister_Click(object sender, RoutedEventArgs e)
        {
            SignUp signObj = new SignUp();
            signObj.Show();
            this.Close();
        }
    }
}
